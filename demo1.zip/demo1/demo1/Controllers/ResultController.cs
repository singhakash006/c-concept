﻿using demo1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace demo1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultController : ControllerBase
    {

        //  private readonly ILogger<ResultController> _logger;


      

        [HttpPost]
        public IActionResult DivideNumbers([FromBody] Entity request)
        {
            Log.Information("POST request received for division: {Numerator} / {Denominator}", request.Numerator, request.Denominator);

            try
            {
                if (request.Denominator == 0)
                {
                    Log.Warning("Attempt to divide by zero detected.");
                    return BadRequest("Denominator cannot be zero.");
                }

                double result = (double)request.Numerator / request.Denominator;
                Log.Information("Division successful. Result: {Result}", result);

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while processing the division: {Message}", ex.Message);
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
    }
}

