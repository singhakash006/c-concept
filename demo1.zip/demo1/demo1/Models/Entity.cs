﻿namespace demo1.Models
{
    public class Entity
    {

        public int Numerator { get; set; }
        public int Denominator { get; set; }
    }
}
